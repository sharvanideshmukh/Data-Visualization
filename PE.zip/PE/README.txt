Multilayered visualization for flights connections

To run the application, move to the directory in which the project is present and run the command:

python -m SimpleHTTPServer 4444

Now, in the browser:

localhost:4444

*** Hover over the bubbles, to get the information about the airport. 
*** Click on a particular state to zoom in to a particular state. 